<!DOCTYPE html>
<html>
<head>
	<title>Associação Académica de Coimbra</title>

     <meta charset="utf-8">
	<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/font-awesome.min.css" rel="stylesheet" media="screen">
    <link href="css/style.css" rel="stylesheet" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,300,100,700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <link href="img/favicon.png" rel="shortcut icon">
    <link rel="stylesheet" href="css/flickity-docs-slide.css" media="screen" />
    <link rel="stylesheet" href="css/lightbox.css" media="screen" />

    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>

    <script src="js/jquery.min.js"></script>
    <script src="js/flickity-docs.min.js"></script>
    <script src="js/randomcores.js"></script>
   
</head>
<body >
	<header style="margin-bottom:10px;" class="branco">
		<div class="container titulo">
			<div class="aac">
				<div class="col-md-1 col-sm-1 col-xs-12">
					<a href="index.php">
						<img src="img/aac2.png" alt="aac"> 
					</a> 
				</div>
				<div class="col-md-11 col-sm-10 col-xs-12 txt">
					| Associação Académica de Coimbra 
				</div>	
			</div> 
		</div>
		
	</header><!-- NAVBAR -->
	<?php
		include 'navbar.html';
	?>
<!--............................  SLIDESHOW + CALENDARIO................................. -->
	<?php
		include 'slideshow.html';
	?>
<!-- .................................................................................... -->


<!--............................  SECTION DE BASE................................. -->
	<section>
		<div class="container cor">
			<div class="tituloPag"> Secções Desportivas</div>
			<div class="info  nucleos">
				<!-- Triggers  Andebol -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="andebol" class="radius button">
					<img  src="img/desporto/andebol.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Andebol </h2>
				</div>

				<!-- Andebol-->
				<div id="andebol" class="reveal-modal" data-reveal>
				  <h2> Andebol </h2>
				  	<img class="img-desporto" src="img/desporto/andebol.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>
				  	Fundada a 17 de Março de 1938, a Secção de Andebol da AAC é uma das Secções mais antigas da AAC, sendo a referência da modalidade na cidade de Coimbra.</p>
					<p>O nosso principal objectivo passa por oferecer aos jovens de Coimbra um contacto directo com a modalidade, apostando na qualidade e excelência de formação das nossas camadas jovens.</p>
					<p>Temos orgulho de receber jovens universitário das mais variadas proveniências que pretendem continuar a praticar a modalidade ao serviço da nossa casa e também nos campeonatos Universitários. </p>
					<br>
					<p><b>Treinos:</b></p>
					<p>Segundas e Sextas das 20h às 22h</p>
					<p>Terças e Quintas das 18h30 às 23h</p>
					<p>Local - Pavilhão nº3 do Estádio Universitário de Coimbra</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>aacandebol@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Sede da Secção - Edíficio da AAC, 4º andar - Horário de atendimento: das 14h às 16h</p>
					<a href="https://pt-pt.facebook.com/academica.andebol" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://aacandebol.blogspot.pt/" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>
				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Atletismo -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="atletismo" class="radius button">
					<img  src="img/desporto/atletismo.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Atletismo </h2>
				</div>

				<!-- Atletismo -->
				<div id="atletismo" class="reveal-modal" data-reveal>
				  <h2> Atletismo </h2>
				  	<img class="img-desporto" src="img/desporto/atletismo.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>Esta é uma Secção orientada para 3 vertentes desportivas: Formação, Manutenção e Competição.</p>
					<p>Nesta última vertente, participa na área federada e universitária.</p>
					<p>A nível universitário, a Secção de Atletismo da AAC, além de ter sido Campeã Nacional de Corta-Mato coletivo, tem tido vários campeões nacionais individuais, quer em corta-mato quer em pista.</p>
					<p>Tem atletas que representaram Portugal nas Universíadas e Mundiais Universitários.</p>
					<p>Esteve ainda vários anos na 1ª Divisão Nacional em masculinos.</p>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Badminton -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="badminton" class="radius button">
					<img  src="img/desporto/badminton.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Badminton </h2>
				</div>

				<!-- Badminton-->
				<div id="badminton" class="reveal-modal" data-reveal>
				  <h2> Badminton </h2>
				  	<img class="img-desporto" src="img/desporto/badminton.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A secção de badminton da AAC foi fundada em 1956. Nesta modalidade, a AAC é dos clubes nacionais mais antigos e respeitados. O nosso trabalho assenta na formação de atletas de onde se destaca o facto de ser a única equipa do país com atletas exclusivamente formados no clube. A secção de badminton vive presentemente o melhor momento da sua história vindo da sua melhor época de sempre onde se destaca o título nacional absoluto de equipas masculinas, o terceiro lugar absoluto de equipas mistas e o terceiro lugar absoluto de equipas femininas. Além disso, temos sido a força dominante no desporto universitário e disso é exemplificativo a conquista da primeira medalha (bronze) ganha por esta modalidade num Campeonato Europeu de Universitários nos últimos Jogos Europeus Universitários disputados em Roterdão. </p>
					<p>Atualmente, a AAC é o clube português de badminton com mais atletas federados em competição permanente, fruto da sua aposta na formação de atletas e treinadores de competência indiscutível aliados a um forte investimento nos treinos de lazer e para a comunidade universitária.</p>
					<br>
					<img style="width:100%;" src="img/desporto/badminton2.png"  onerror="this.src='notfound.png'" alt="nucleo">
					<br>
					<p><b>Localização:</b></p>
					<p>Edifício Sede AAC; Estádio Universitário de Coimbra</p>
					<a href="https://www.facebook.com/aacbadminton" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Basebol -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="basebol" class="radius button">
					<img  src="img/desporto/basebol.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Basebol </h2>
				</div>

				<!-- Basebol-->
				<div id="basebol" class="reveal-modal" data-reveal>
				  <h2> Basebol Softbol</h2>
				  	<img class="img-desporto" src="img/desporto/basebol.png"  onerror="this.src='notfound.png'" alt="nucleo">
				 	<p>Fundação: 24 de Outubro de 1988</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>academicabasebolsoftbol@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Rua Padre António Vieira, 3000-315 Coimbra</p>
					<a href="https://www.facebook.com/academicabasebolsoftbol" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="https://sites.google.com/site/academicabasebolsoftbol/" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Basquetbol -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="basquetebol" class="radius button">
					<img  src="img/desporto/basquetebol.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Basquetebol </h2>
				</div>

				<!-- Basquetebol-->
				<div id="basquetebol" class="reveal-modal" data-reveal>
				  <h2> Basquetebol </h2>
				  	<img class="img-desporto" src="img/desporto/basquetebol.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Basquetebol da AAC tem um dos historiais mais gloriosos dentro da AAC, tendo-se sagrado várias vezes Campeão Nacional.</p>
					<p>Além dos planteis seniores a AAC conta com equipas de todos os escalões de formação jogando nos diversos campeonatos distritais e nacionais, tendo conseguido, ao longo dos anos, importantes conquistas e feitos assinaláveis.</p>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers Bilhar -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="bilhar" class="radius button">
					<img  src="img/desporto/bilhar.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2>Bilhar </h2>
				</div>

				<!-- Bilhar-->
				<div id="bilhar" class="reveal-modal" data-reveal>
				  <h2> Bilhar</h2>
				  	<img class="img-desporto" src="img/desporto/bilhar.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Bilhar da pretende dinamizar a modalidade do bilhar no seio da comunidade universitária e ao mesmo tempo aumentar o ecletismo desportivo da AAC.</p>
					<p>Após o período de Pro-Secção de Bilhar da Associação Académica de Coimbra, a Secção de Bilhar da AAC, criada no dia 12 de Dezembro de 2009, quer dar seguimento com os objectivos de dinamizar a modalidade do Bilhar, Desporto Olímpico, no seio da comunidade universitária e ao mesmo tempo aumentar o ecletismo desportivo da Associação Académica de Coimbra.</p>
					<p>Nesse período inicial, incidiu a sua actividade desportiva com a participação no Campeonato Nacional de Pool, na Taça de Portugal de Pool, no Campeonato Distrital de Pool Português, na Taça de Portugal de Pool Português e no BCA – 8 Ball World Championship.</p>
					<p>Para além disto, já organizou diversos torneios para federados e não federados, bem como provas da Federação Portuguesa de Bilhar.</p>
					<p>Em Maio de 2010, realizou o 1º Torneio de Pool da Queima das Fitas de Coimbra.</p>
					<p>A secção de Bilhar da AAC está a iniciar a Escola de Bilhar nas suas novas instalações, para jovens e estudantes universitários. Para promoção e divulgação do desporto junto da comunidade universitária está a organizar iniciativas em conjunto com diversas secções e núcleos da Associação Académica de Coimbra.</p>
					<p>Formou recentemente juntamente com outros clubes a Associação de Bilhar de Coimbra, onde assume lugar de destaque na direcção nomeadamente a presidência.</p>
					<p>Inaugurou as suas instalações desportivas, sitas no Estádio Cidade de Coimbra, Porta 5B, em Setembro de 2010.</p>
					Disputa os Campeonatos Nacionais e Taça de Portugal de todas as variantes de Pool com equipas masculinas e 1 equipa feminina.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Boxe -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="boxe" class="radius button">
					<img  src="img/desporto/boxe.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Boxe </h2>
				</div>

				<!-- Boxe-->
				<div id="boxe" class="reveal-modal" data-reveal>
				  <h2> Boxe </h2>
				  	<img class="img-desporto" src="img/desporto/boxe.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>Esta secção está aberta a todos os escalões e sexos, tendo uma equipa feminina de considerável número.</p>
					<p>Disponibiliza a prática das modalidades amadora e olímpica.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Cultura Física -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="CFisica" class="radius button">
					<img  src="img/desporto/culturafisica.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Cultura Física </h2>
				</div>

				<!--Cultura Física-->
				<div id="CFisica" class="reveal-modal" data-reveal>
				  <h2> Cultura Física </h2>
				  	<img class="img-desporto" src="img/desporto/culturafisica.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Cultura Física da AAC foi fundada em 1969. A nossa sala está equipada com aparelhos de cardio fitness e de musculação. As modalidades que decorrem no nosso espaço são o culturismo masculino/feminino e powerlifting. </p>
				  	<br>
					<p><b>Horário:</b></p>
					<p>Segunda a Sexta das 10h00 às 22h30</p> 
					<p>Sábado das 10h00 às 13h00 e das 16h00 às 19h00.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>aacculturafisica@hotmail.com</p>
					<p>239 810 793</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Estádio Universitário</p>
					<a href="https://www.facebook.com/pages/Sec%C3%A7%C3%A3o-de-Cultura-F%C3%ADsica-Associa%C3%A7%C3%A3o-Acad%C3%A9mica-de-Coimbra/130681903778623?fref=ts" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
					

				<!-- Triggers  Desportos Motorizados -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="DMotorizados" class="radius button">
					<img  src="img/desporto/motorizados.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Desportos Motorizados </h2>
				</div>

				<!--Desportos Motorizados-->
				<div id="DMotorizados" class="reveal-modal" data-reveal>
				  <h2> Desportos Motorizados </h2>
				  	<img class="img-desporto" src="img/desporto/motorizados.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Desportos Motorizados da Associação Académica de Coimbra foi criada no ano de 2004 por um grupo de estudantes universitários que sentiu necessidade de divulgar e fomentar a prática de desportos “com motor” na cidade de Coimbra em geral e na comunidade universitária em particular. A SDM/AAC conta já com um activo de cerca de 71 sócios e de 20 pilotos, muitos deles com resultados de bastante relevo no panorama automobilístico nacional. </p>
				  	<p> Na sua actividade regular contam-se a organização e a participação em Campeonatos Nacionais de diversas modalidades (Navegação e Trial 4x4, TT, UTV/Buggy, Kartcross, Regularidade Histórica, Rali de Montanha, Motocross, Karting), a organização de eventos direccionados essencialmente para a comunidade universitária e para a cidade de Coimbra (corridas de Kart, Rally Papper, Track day’s, Passeios TT e Acções de formação, Troféu de Karting e mais recentemente a reedição do Rali Queima das Fitas), bem como a presença em certames diversos (ExpoAventura, Mostra Desportiva AAC, Feira ACIC, Exposição de Automóveis Antigos e Clássicos de Coimbra, ExpoFigueira). </p>
					<p>Assente na vontade e dedicação dos seus dirigentes e associados, a SDM/AAC pretende continuar a promover o Desporto Automóvel e a dignificar a instituição que representa e os seus patrocinadores, de quem muito se orgulha, sempre consciente da necessidade de trabalho, partilha e aperfeiçoamento, sob o lema: “Hoje pequenos, amanhã se possível maiores”.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>motorizados@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Rua Padre António Vieira, nº1 - Edifício da AAC - 4º Piso</p>
					<a href="https://www.facebook.com/sdmaac" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="http://sdm-aac.blogspot.pt/" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>
				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->



				<!-- Triggers  Desportos Naúticos -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="DNauticos" class="radius button">
					<img  src="img/desporto/nauticos.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Desportos Naúticos </h2>
				</div>

				<!--Desportos Naúticos-->
				<div id="DNauticos" class="reveal-modal" data-reveal>
				  <h2> Desportos Naúticos </h2>
				  	<img class="img-desporto" src="img/desporto/nauticos.png"  onerror="this.src='notfound.png'" alt="nucleo">
				 	<p>A Secção de Desportos Náuticos tem desenvolvido desde a data da sua fundação, em 1982, um esforço para a promoção e o desenvolvimento dos Desportos Náuticos na cidade de Coimbra.</p>
				  	<p>Actualmente, a sua principal modalidade desportiva é o Remo, que funciona em três graus diferentes: escola, lazer e competição. O esforço, tanto a nível de implementação da modalidade, como a nível de resultados, tem sido recompensado: a Secção de Desportos Náuticos sagrou-se Campeã Nacional de Clubes em 2007/08, 2008/09 e 2009/10, contando no seu historial mais de 100 títulos nacionais nos diversos escalões, bem como a internacionalização de vários dos seus atletas ao serviço da Equipa Nacional, em Campeonatos do Mundo, Universíadas e outros eventos.</p>
					<p>Se podemos considerar o Desporto de Competição como o mais espectacular e capaz de movimentar grandes massas humanas, não é menos verdade que a prática desportiva como actividade lúdica é de extrema importância e constitui uma actividade com grande expressão nos países mais desenvolvidos da Europa. E é neste sentido que a Secção procura encaminhar as suas actividades.</p>
					<p>O desporto ao serviço da população ganha cada vez mais preponderância, numa sociedade cada vez mais ávida de lazer activo.</p>
					<p>Horário Secretaria: dias úteis das 15h às 20h</p>
					<p>Modalidade desportiva: remo, nas vertentes de competição e lazer</p>
					<p>Quota mensal: 30€ geral, estudantes universitários 25€</p>
					<p>Informações e inscrições através de telefone, email ou nas nossas instalações no Centro Náutico do Parque Verde.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>geral@aac-nauticos.com</p>
					<p>239 810 023</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Rua Padre António Vieira, nº1 - Edifício da AAC - 4º Piso</p>
					<a href="https://www.facebook.com/desportosnauticos.aac.1" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="http://www.aac-nauticos.com/v2/" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Futebol -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="futebol" class="radius button">
					<img  src="img/desporto/lel.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Futebol </h2>
				</div>

				<!--Futebol-->
				<div id="futebol" class="reveal-modal" data-reveal>
				  <h2> Futebol </h2>
				  	<img class="img-desporto" src="img/desporto/futebol.png"  onerror="this.src='notfound.png'" alt="secção desportiva">
				  	<p>A Associação Académica de Coimbra – Secção de Futebol, atualmente disputa a Divisão de Honra da Associação Futebol de Coimbra.</p>
					<p>Trata-se de um clube diferente de todos os outros, sem remunerações ou prémios de jogos, totalmente composto por estudantes universitários da academia de Coimbra, desde o Presidente aos jogadores.</p>
					<p>Quem chega a Coimbra como caloiro Universitário e veste a camisola da Académica sente o espírito e o orgulho de fazer parte de um clube histórico ao qual ficará, inevitavelmente, para sempre ligado.</p>
					<p>No palmarés destaca-se a vitória na primeira edição da Taça de Portugal.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Ginástica -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="ginastica" class="radius button">
					<img  src="img/desporto/lel.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Ginástica </h2>
				</div>

				<!--Ginástica-->
				<div id="ginastica" class="reveal-modal" data-reveal>
				  <h2> Ginástica </h2>
				  	<img class="img-desporto" src="img/desporto/nea.png"  onerror="this.src='notfound.png'" alt="secção desportiva">
				  		<p><b>Contacto:</b></p>
						<p>acginastica@gmail.com</p>
						<p>239 810 023</p>
						<br>
						<p><b>Localização:</b></p>
						<p>Secção de Ginástica</p>
						<p>Associação Académica de Coimbra  R. Padre António Vieira, N.º1 - 5º , 3000-315 Coimbra</p>
						<br>
						<p><b>Local de Treinos:</b></p>
						<p>Estádio Universitário de Coimbra - Pavilhão 2 (Todos os dias a partir das 17:00h), Antanhol - Armazéns da Plural</p>
						<a href="https://www.facebook.com/aacginastica" target="_blank;">
						<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
						</a>
						<a href="http://www.aacginastica.net" target="_blank;">
						<i class="fa fa-plus fa-2x" style="color:black"></i>
						</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Halterofilismo -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="alterofilismo" class="radius button">
					<img  src="img/desporto/halterofilismo.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Halterofilismo </h2>
				</div>

				<!--Halterofilismo-->
				<div id="alterofilismo" class="reveal-modal" data-reveal>
				  <h2> Halterofilismo </h2>
				  	<img class="img-desporto" src="img/desporto/halterofilismo.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>Sendo um dos poucos clubes que pratica Halterofilismo na região, tem havido uma aposta forte na comunidade estudantil, seja universitária ou do ensino secundário.</p>
					<p>Estando voltada maioritariamente para a vertente competitiva, como se atesta pelos diversos títulos conquistados nos últimos anos, o grupo de atletas, embora diminuto, é caracterizado pelo seu espírito de camaradagem e entreajuda.</p>
					<p>Para a prática da modalidade não é necessário uma força humana, mas apenas vontade de aprender.</p>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Judo -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="judo" class="radius button">
					<img  src="img/desporto/judo.jpg" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Judo </h2>
				</div>

				<!--Judo-->
				<div id="judo" class="reveal-modal" data-reveal>
				  <h2> Judo </h2>
				  	<img class="img-desporto" src="img/desporto/judo.jpg"  onerror="this.src='notfound.png'" alt="secção desportiva">
				 	<p>A Secção de Judo da AAC é um dos clubes mais antigos da história do Judo em Portugal, contando 55 anos de história. O Judo/AAC é uma das referências da modalidade e também um dos clubes mais representativos de Portugal, tendo mais de uma dezena de treinadores cinto negro e cerca de 200 atletas. Com treinos diários nas diversas classes, o bem preparado corpo técnico da secção é responsável pela orientação de duas centenas de praticantes.</p>
				  	<p>A secção de Judo marca presença nas mais diversas provas nacionais e internacionais, bem como noutro tipo de eventos, nomeadamente estágios de aperfeiçoamento técnico/competitivo.</p>
					<p>Ao nível desportivo o Judo da Académica conta com campeões nacionais em todas as categorias etárias e sobe regularmente ao pódio nas diversas competições por equipas.Estes resultados têm levado a que os atletas da Académica sejam regularmente chamados aos trabalhos da selecção nacional, representando o país em inúmeras ocasiões, nomeadamente Campeonatos da Europa e do Mundo dos diversos escalões, onde também têm atingido o sucesso. Em 2014 a jovem atleta Catarina Costa alcançou honrosos quintos lugares no Campeonato da Europa e do Mundo de Juniores e Lúcio Conceição, nos Veteranos, sagrou-se Vice-Campeão do Mundo. No panorama nacional os academistas conquistaram mais de vinte medalhas nacionais, dos quais sete se sagraram Campeões Nacionais.</p>
					<p>￼Também ao nível organizativo a Secção de Judo da Associação Académica de Coimbra deixa regularmente a sua marca no panorama do Judo nacional já que é responsável pela mais forte competição de equipas em Portugal, o Torneio da Queima das Fitas, e realiza anualmente o maior estágio de Judo a nível nacional, sendo este último já uma referência europeia.</p>
					
					<br>
					<p><b>Horário de Funcionamento:</b></p> 
					<p>Secretaria - 2ª a 6ª feira das 18h às 20h</p> 
					<br>
					<p><b>Treinos:</b></p>
					<p>2ª a 6ª feira das 17h45 às 21h30</p>
					<br>
					<img style="width:100%;" src="img/desporto/judo2.jpg"  onerror="this.src='notfound.png'" alt="nucleo">
					<br>
					<p><b>Contacto:</b></p>
					<p>geral@judoaac.com</p>
					<p>239 810 023</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Sala de Judo do Pavilhão nº2 do Estádio Universitário de Coimbra (Santa Clara)</p>
					<a href="https://www.facebook.com/JudoAAC" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="http://www.judoaac.com " target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Lutas Amadoras -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="lutas" class="radius button">
					<img  src="img/desporto/lutas.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Lutas Amadoras </h2>
				</div>

				<!--Lutas Amadoras-->
				<div id="lutas" class="reveal-modal" data-reveal>
				  <h2> Lutas Amadoras </h2>
				  	<img class="img-desporto" src="img/desporto/lutas.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Lutas Amadoras da AAC disponibiliza a prática de Luta Greco-Romana e Luta Livre Olímpica.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Karaté -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="karate" class="radius button">
					<img  src="img/desporto/karate.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Karaté </h2>
				</div>

				<!--Karaté-->
				<div id="karate" class="reveal-modal" data-reveal>
				  <h2> Karaté </h2>
				  	<img class="img-desporto" src="img/desporto/karate.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Karaté da Associação Académica de Coimbra, foi fundada em 1974 por um grupo de estudantes da Academia. Desde a sua fundação, teve como referência o Karatê-Dô Shotokan (do regulamento interno) e ao falarmos de Shotokan, à época, entende-se Japan Karate Association-JKA, que, após tumultuosas agitações no seu seio, ficaram como principais referências Gichin Funakoshi e Masatoshi Nakayama (fundadores da JKA).</p>
					<p>Até 1977 a secção teve pouca relevância no plano nacional, estatuto somente adquirido a partir dessa data com a contratação do Mestre José Arlindo Lemos e a colaboração de José Melo, protagonistas que não podemos deixar de referir, pela mais-valia técnica, bem como nos destinos ideológicos preconizados pelos grandes Mestres. Actualmente conta com cerca de 60 praticantes regulares, com três sessões de treino diários e cinco classes, desde os iniciados infantis aos graduados adultos. A formação, o lazer e a competição são os seus principais objectivos, tendo sempre presente a sua componente educativa e formativa “do carácter do ser humano”.</p>
					<p>A secção recebe gratuitamente jovens de instituições de cariz social (Lar São Francisco de Assis), participa em férias desportivas para jovens (Coimbra, Figueira da Foz, etc.), organiza provas desportivas (Taça Cidade de Coimbra, Queima das Fitas, Festa das Latas, Torneio Universitário, Campeonatos da Federação e da Liga Shotokan), estágios, cursos nacionais e internacionais (1997/99) Mestre Keinosuke Enoeda, (1998) Mestre Minoro Kawawada, Mestre Ilia Yorga, Mestre José Ramos, bem como demonstrações públicas (Casa do Povo de Oliveira do Hospital, Câmara Municipal de Coimbra, Penela, Pombal, etc.) e acções que enriquecem e dinamizam o panorama desportivo da Cidade e a região de Coimbra.</p>
					<p>No plano competitivo, a secção tem um vasto conjunto de títulos de campeões nacionais, conseguido ao longo dos anos, nos torneios, campeonatos nacionais e internacionais, com destaque para os títulos de vice-campeão europeu EAKF, Rui Diz (Sanderland – 1987) vice campeões europeus equipas (Milão – 1989), campeões por equipas do torneio europeu em Pau (França 1988), finalistas do campeonato europeu por equipas feminino em St. Pollten (Áustria 1997), campeões individuais (Augusto Patrício) e equipas do torneio Ibérico em Jaen (Espanha-2002) e campeão europeu júnior (Chipre-2002).</p>
					<p>Atualmente, no âmbito da competição, a secção tem vindo a desenvolver um programa de trabalho com os escalões mais jovens, para dar resposta a médio e longo prazo, às actuais exigências competitivas.</p>
					<p>A secção é sócia fundadora da Associação Portuguesa de Karaté Shotokan (APKS ou APK-SHO), está filiada na Liga Portuguesa de Karaté Shotokan (LPKS) e na Federação Nacional de Karaté – Portugal (FNK-P). Pratica o estilo SHOTOKAN dos Mestres Gichin FUNAKOSHI e Masatoshi NAKAYAMA.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->



				<!-- Triggers  Natação -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="natacao" class="radius button">
					<img  src="img/desporto/natacao.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Natação </h2>
				</div>

				<!--Natação-->
				<div id="natacao" class="reveal-modal" data-reveal>
				  <h2> Natação </h2>
				  	<img class="img-desporto" src="img/desporto/natacao.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Natação / Triatlo da Associação Académica de Coimbra (SNAAC) é uma instituição desportiva de utilidade pública com uma grande tradição no âmbito da natação.</p>
					<p>Ao nível competitivo a equipa de natação está envolvida em cerca de 50 competições, regionais, nacionais e internacionais, desde os cadetes aos seniores, sendo também a melhor equipa nacional tanto no sector masculino, como feminino, no escalão Master.</p>
					<p>Seguindo uma grande tradição desportiva, iniciada em 1935 com a criação desta Secção, conta com cerca de 200 atletas federados em todos os escalões. Ao nível dos resultados destacamos a participação de dois atletas no campeonato da Europa de juniores nos últimos anos e a detenção de vários recordes regionais e nacionais.</p>
					<p>Ao nível da formação, a natação da AAC proporciona na presente época desportiva o ensino da natação a cerca de três dezenas de escolas e colégios da região de Coimbra, servindo ainda uma população de cerca de 1000 utentes, nas piscinas Rui Abreu, Complexo Olímpico de Piscinas de Coimbra e Piscina Luís Lopes da Conceição, sendo que os Estudantes universitários usufruem condições especiais.</p>
					<p>A AAC está a relançar a modalidade de polo aquático, criando uma escola de formação e competindo na 2ª Divisão com a sua equipa Sénior Masculina.</p>
					<p>A Secção de Natação da Associação Académica de Coimbra realiza há 25 anos o Meeting Internacional Cidade de Coimbra, considerado nas suas últimas 5 edições o melhor Meeting Internacional efectuado em Portugal, sendo reconhecido pela Federação Portuguesa de Natação e pela Liga Europeia de Natação como uma prova de referência do panorama internacional.</p>
					<p>Este Meeting tem sido uma prioridade para atletas de todo o mundo estando sistematicamente presentes atletas Olímpicos, Recordistas Mundiais, Medalhados Olímpicos, Recordistas e Campeões Pan-Americanos e Vencedores da Taça do Mundo.</p>
					<p>Quanto às modalidades de Triatlo/Duatlo/Aquatlo o Clube relançou a modalidade como alternativa desportiva, da AAC a toda a população coimbrã e amante das modalidades de endurance; Entendemos que como Secção de Natação somos os que estamos mais bem preparados para responder às inúmeras solicitações que nos têm sido postas pelos “Triatletas” da cidade e da sua Academia, bem como da Federação Triatlo de Portugal e da Câmara Municipal de Coimbra. Assim, entendeu a Direcção Geral da AAC, delegar na Secção de Natação a seu pedido a criação desta resposta: O clube de triatlo de Coimbra é a Associação Académica de Coimbra, de forma a poder dar resposta também à sua população Universitária (aprox. 21.000 estudantes). Pelo que foi criada uma escola de formação de Triatlo/Duatlo/Aquatlo, para todas as idades, assim como uma equipa de competição de Triatlo/Duatlo/Aquatlo, que tem como figura de topo o atleta José Estrangeiro que foi Campeão Europeu.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Patinagem -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="patinagem" class="radius button">
					<img  src="img/desporto/patinagem.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Patinagem </h2>
				</div>

				<!--Patinagem-->
				<div id="patinagem" class="reveal-modal" data-reveal>
				  <h2> Patinagem </h2>
				  	<img class="img-desporto" src="img/desporto/patinagem.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>A Secção de Patinagem da Associação Académica de Coimbra foi fundada em Janeiro de 1938.</p>
					<p>Atualmente tem todos os escalões etários em atividade, num total de 10 equipas e de mais de 150 atletas, desde as escolas de iniciação até à competição federada e envolvidas em competições regionais e nacionais.</p>
					<p>Tem como objetivos desenvolver e incrementar a prática e o gosto pela patinagem, não só junto dos estudantes da Universidade de Coimbra, como também junto dos habitantes da cidade e da população em geral, bem como desenvolver nos seus atletas uma postura desportiva representando condignamente a Associação Académica de Coimbra em todas as disciplinas na patinagem.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Pesca Desportiva -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="pesca" class="radius button">
					<img  src="img/desporto/pesca.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Pesca Desportiva </h2>
				</div>

				<!--Pesca Desportiva-->
				<div id="pesca" class="reveal-modal" data-reveal>
				  <h2> Pesca Desportiva </h2>
				  	<img class="img-desporto" src="img/desporto/pesca.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>No início de 1979 são dados os primeiros passos, ainda sem instalações, sob a égide da Direção Geral e do Conselho Desportivo da AAC. Esse ano foi aproveitado para delinear os princípios programáticos e desportivos que iriam ser seguidos, a organização do Regulamento Interno (frequentemente atualizado), a angariação de sócios, os primeiros eventos, as primeiras competições e a própria integração nas dinâmicas da Instituição.</p>
					<p>Belisário Borges, o empreendedor inicial, procurou rodear-se de pessoas que, como ele, sentiam a urgência de um clube com importância e prestígio no panorama da Pesca Desportiva regional e nacional. Assim, coadjuvado por Carlos Balteiro, Costa Pinto, Jaime Pinto Fernandes, Arlindo Santiago, António Lopes e Luís Filipe Almeida, os fundadores, foi possível logo no início de 1980, à boa maneira do P.R.E.C., tomar de assalto a sala do movimento democrático das mulheres (M.D.M.), então sem qualquer atividade mas que ninguém queria ceder. Nesta fase, foi decisivo o contributo de João Amora, recém-licenciado em Medicina, o qual, sem mais atrasos, ocupou o espaço onde ainda hoje nos encontramos.</p>
					<p>A partir daí, foi um trabalho permanente de formação, organização de eventos, torneios (dos quais se destacam o “Portugal Académica Super”, o Torneio Triangular, o Pentatlo da Água, o Pescaloiros, as 6 Hora do Mondego, entre outros ), sistematização de métodos, treinos na procura constante das melhores soluções; de frustrações e de falhas mas igualmente de evolução e crescimento com êxitos inigualáveis e nunca conseguidos por qualquer outra Secção da A.A.C. como a conquista de 5 campeonatos regionais, 2 taças associativas, o de Campeões Nacionais de Clubes da 1ª Divisão em 1991 e logo a seguir o de CAMPEÕES DO MUNDO DE CLUBES em 1992, troféu conquistado em Espanha (Mérida, canal do Guadiana) com uma equipa de jovens estudantes que venceram categoricamente 20 seleções de várias nações, algumas das quais com equipas profissionalizadas (os ingleses do Isaac Walter Silstar’s Team, ou os italianos da Trabucco). Sublinhe-se ainda que foi a primeira vez que uma equipa portuguesa logrou conquistar este valioso troféu, conseguido pela Secção de Pesca Desportiva da AAC.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Radiomodelismo -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="radiomodelismo" class="radius button">
					<img  src="img/desporto/radiomodelismo.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Radiomodelismo </h2>
				</div>

				<!--Radiomodelismo-->
				<div id="radiomodelismo" class="reveal-modal" data-reveal>
				  <h2> Radiomodelismo </h2>
				  	<img class="img-desporto" src="img/desporto/radiomodelismo.png"  onerror="this.src='notfound.png'" alt="secção desportiva">
				  	<p>A Secção de Radiomodelismo foi criada a 18 de Dezembro de 1991 pelo Presidente da DG/AAC Emídio Guerreiro. Foram sua primeira direção os seguintes elementos: Virgílio Caseiro – Presidente; Carlos Lobo – Vice-Presidente; António Macedo -Tesoureiro.</p>
					  <p>Tem instalações desportivas no Estádio Universitário, Mini – Autódromo para a prática do Radiomodelismo, onde funcionam também alguns dos serviços administrativos da Secção.</p>
					  <p>Ainda no ano de 1991, a Secção inscreveu-se na então provisória Federação Portuguesa de Radiomodelismo Automóvel, tendo vindo ininterruptamente desde essa data a organizar provas desportivas de âmbito académico, regional, nacional e internacional. A Secção é sócia fundadora da atual federação(FEPRA).</p>
					 <p>Todos os anos tem organizado provas integradas no Campeonato Nacional da modalidade de Todo-o-Terreno, escala 1/8 TT, tendo mesmo sido escolhida, em 1993, pela Federação Portuguesa, para organizar o respetivo Campeonato Europeu.</p>
					 <p>A International Federation of Model Auto Racing atribui à Secção de Radiomodelismo da AAC a organização do VIII Campeonato do Mundo de 1/8 T.T, que foi realizado com sucesso no Estádio Universitário, merecendo das entidades internacionais, a nível organizativo, uma classificação de 9,8 numa pontuação de 0 a 10.</p>
					 <p>Em 2000, a pista de TT dá lugar ao atual miniautódromo de velocidade onde em 2001 é organizado uma prova a contar para o campeonato da Europa na escala 1/8 pista.</p>
					 <p>Todos os anos temos atletas que representam Portugal nas várias provas internacionais através da FEPRA.</p>
					 <p>Resultados Desportivos:</p>
					 <p>11 Campeonatos Regionais individuais</p>
					<p>36 Campeonatos Nacionais Individuais</p>
					<p>20 Participações em finais de Campeonatos Europeus e Mundiais</p>
					<p>1 Campeão Europeu</p>
					<p>8 Títulos de Campeões Regionais por equipes</p>
					<p>18 Títulos de Campeões Nacionais por equipes</p>
					<p>24 Taças de Portugal</p>
					<p>Prémio Prestígio Salgado Zenha (Virgilio Caseiro)</p>
					<p>Prémio Dirigente do Ano Salgado Zenha (Carlos Lobo)</p>
					<p>Prémio Dirigente do ano Diário as Beiras (Carlos Lobo)</p>
					<p>Secção do Ano em 1998</p>
					<p>Atleta do Ano – Miguel Matias</p>
					</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>pista.aac@gmail.com</p>
					<br>
					<p><b>Local de Treinos:</b></p>
					<p>Mini Autódromo Situado no Estádio Universitário</p>
					<br>
					<img  src="img/desporto/radiomodelismo2.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					<p>Pista de Radiomodelismo da Secção de Radiomodelismo no Estádio Universitário de Coimbra</p>
					

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Rugby -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="rugby" class="radius button">
					<img  src="img/desporto/rugby.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Rugby </h2>
				</div>

				<!--Rugby-->
				<div id="rugby" class="reveal-modal" data-reveal>
				  <h2> Rugby </h2>
				  	<img class="img-desporto" src="img/desporto/rugby.png"  onerror="this.src='notfound.png'" alt="secção desportiva">
				  	<p>Em 1936 o Dr. José Maria Antunes começa a juntar uma rapaziada e a dar os primeiros passos na modalidade.</p>
					<p>Para incentivar essa implantação faz-se na Queima das Fitas de 1937 um jogo de demonstração no campo de St.ª Cruz entre duas equipas de Lisboa (Veterinária e Comercial) que a primeira vence por 6-3.</p>
					<p>O jogo começa a ter adeptos e praticantes.</p>
					<p>Forma-se uma equipa, treina-se e… no dia 6 de Maio de 1940, no campo do Arnado (em Coimbra), durante os jogos desportivos universitários a Associação Académica de Coimbra joga a final com a Universidade Técnica de Lisboa perdendo por 6-3. É num jogo realizado em Coimbra (campo do Arnado) no dia 2 de Junho de 1942 que a AAC ganha o seu primeiro jogo, vencendo Lisboa por 8-0.</p>
					<p>E assim acaba o primeiro período de Rugby da AAC.</p>
					<p>Após alguns anos de interregno vem estudar para Coimbra (54-55) António Sá Lima. Com ele se iniciou a restauração do Rugby e se estrutura a Secção que se mantém até hoje.</p>
					<p>A Secção de Rugby filia-se em 55/56 na A.R.L (Associação de Rugby de Lisboa) já que ainda não existia a F.P.R. (Federação Portuguesa de Rugby), que só aparece em 57/58 e disputa em Coimbra a final do primeiro Campeonato de Portugal (se assim se pode chamar), defrontando o C.F.”Os Belenenses” e perdendo por 40-0.</p>
					<p>Como sócio fundador, filia-se em 57/58 na F.P.R. e vai disputando vários campeonatos federados e universitários.</p>
					<p>Em 17 de Março de 1960 disputa em Coimbra (Estádio Municipal) o seu primeiro jogo internacional defrontando a equipa inglesa de St. John College de Oxford, perdendo por 48-0.</p>
					<p>Passa-se a jogar e a treinar no novo Estádio Universitário e inaugura-se o campo no dia 3 de Março de 1963 com uma vitória sobre o Futebol Benfica por 18-0. Nesse ano, em Maio, recebe e vence os campeões de Espanha, a Escola Superior de Arquitectura de Madrid por 6-3.</p>
					<p>O jogo ganha raízes profundas e em 1970 pela mão de Manuel Costa ganhamos o primeiro título, o Torneio de Abertura.</p>
					<p>No dia 2 de Junho de 1974, a Académica ganha em Coimbra ao S.L. Benfica por 15-12 conquistando pela primeira vez a Taça de Portugal.</p>
					<p>O primeiro título de Campeão Nacional Sénior da 1ª Divisão aparece em 76/77 e volta a conquistar o título dois anos depois, 78/79.</p>
					<p>Após a conquista das Taças de Portugal de 94/95 e 95/96 e o segundo lugar no campeonato de 94/95, a Associação Académica de Coimbra conquistou na época de 1996/97 o seu 3º Campeonato Nacional da 1ª Divisão a Supertaça – Festival 5 de Outubro, a Taça Primavera, a Taça de Portugal e a Taça Ibérica, feito histórico, uma vez que jamais alguma equipa portuguesa o conseguiu…</p>
					<p>Nas 7 épocas seguintes, a secção de rugby, apesar de não ter conquistado qualquer título ao nível do escalão sénior, conquistou inúmeros campeonatos pelos seus escalões de formação: iniciados, juvenis, e com especial destaque para a conquista do campeonato da equipa Júnior na época 99/00, já que na altura, era o único escalão pelo qual a AAC ainda não tinha sido campeã nacional.</p>
					<p>Há a registar que o único título em faltava no palmarés da secção é a Taça de Portugal de Juniores, competição em que fomos finalistas inúmeras vezes, sem nunca termos tido conseguido porém trazer a taça para Coimbra, feito esse conseguido na época de 2007/08.</p>
					<p>Na época de 2003/2004, a AAC conquistou o seu 4º título nacional, num campeonato disputadíssimo, decidido na última jornada, na Tapada da Ajuda, frente ao Agronomia.</p>
					<p>Os últimos títulos conquistados no escalão sénior foram o Campeonato Nacional da 1ª Divisão e o Circuito nacional de 7’s na época de 2006/07.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Taekwondo -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="taekwondo" class="radius button">
					<img  src="img/desporto/taekwondo.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Taekwondo </h2>
				</div>

				<!--Taekwondo-->
				<div id="taekwondo" class="reveal-modal" data-reveal>
				  <h2> Taekwondo </h2>
				  	<img class="img-desporto" src="img/desporto/taekwondo.png"  onerror="this.src='notfound.png'" alt="secção desportiva">
				  	<p>O Taekwondo é uma Arte Marcial que é oriunda da Coreia do Sul, e que foi considerada Modalidade Olímpica em 2000.</p>
					<p>A Secção de Taekwondo da AAC foi criada em 2001 e visa criar uma equipa de competição, dar formação a todos os estudantes que assim desejarem, a nível de defesa pessoal e ocupar tempos livres.</p>



				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


				<!-- Triggers  Ténis -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="tenis" class="radius button">
					<img  src="img/desporto/tenis.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Ténis </h2>
				</div>

				<!--Ténis-->
				<div id="tenis" class="reveal-modal" data-reveal>
				  <h2> Ténis </h2>
				  	<img class="img-desporto" src="img/desporto/tenis.png"  onerror="this.src='notfound.png'" alt="secção desportiva">
				  <p>Fundação: maio de 1958.</p>
				  <p>A Secção de Ténis da Associação Académica de Coimbra desenvolve as actividades no Estádio Universitário de Coimbra. Dispõe de 6 campos de piso rápido exteriores e 3 campos de piso rápido cobertos, todos eles com iluminação artificial. Incentivamos a todos a prática desportiva através de uma escola de ténis que incorpora todas as idades e níveis de aprendizagem (Iniciação; Aperfeiçoamento; Competição; Desporto Universitário.)</p>
				  <p>Palmarés (Principais Conquistas)</p>
				  <p>Campeonato Nacional de Equipas(Federação Portuguesa de Ténis)</p>
				  <p>1º Divisão Masculina: </p>
				  <p>Campeã: 2004.</p>
				  <p>1ª Divisão Feminina:</p>
				  <p>Campeã: 2002, 2003, 2004, 2006, 2007, 2008.</p>
				  <p>Vice-Campeã: 2010, 2011.</p>
				  <p>2º Divisão Masculina:</p>
				  <p>Campeã: 2000, 2002, 2008, 2011, 2012, 2013.</p>
				  <p>2ª Divisão Feminina:</p>
				  <p>Campeã: 2009, 2010, 2013.</p>
				  <p>Vice-Campeã: 2011.</p>
				  <p>3ª Divisão Masculina:</p>
				  <p>Campeã: 2011, 2012, 2013.</p>
				  <p>Vice-Campeã: 2010.</p>
				  <p>Sub14 Femininos:</p>
				  <p>Campeã: 2011, 2013.</p>
				  <p>Sub16 Femininos:</p>
				  <p>Campeã: 2006, 2009, 2012.</p>
				  <p>Sub18 Femininos:</p>
				  <p>Campeã: 2004.</p>
				  <br>
				  <p>Campeonato Nacional Individual:</p>
				  <p>Vencedores: MartimTrueva, Bárbara Luz, Rita Vilaça, Matilde Fernandes.</p>
				  <br>
				  <p>FADU – Federação Académica do Desporto Universitário</p>
				  <p>Campeã Nacional de Equipas: 2001-02, 2011-12, 2013-14.</p>
				  <p>Vice-Campeã: 2012-13.</p>
				  <br>
				  <p>Outros Registos/ Eventos:</p>
				  <p>- Campeonato Europeu Universitário 2010 – Organização</p>
				  <p>- Prémio em Conjunto AAC – EUSA Games Córdoba 2012 – Vencedores</p>
				  <p>- Internacional Sub12 – Memorial Lúcio Vaz</p>
				  <p>- International Tennis Federation Coimbra – 25.000 WTA (CircuitoProfissional Fem.)</p>
				  <p>- International Tennis Federation Coimbra – 10.000 WTA (CircuitoProfissional Fem.)</p>
				  <br>
				  <p><b>Contacto:</b></p>
					<p>aac.escola.tenis@gmail.com</p>
					<p>239 441 433</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Estádio Universitário de Coimbra</p>
					
					<a href="https://www.facebook.com/tenisAAC" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="https://plus.google.com/u/0/+EscoladeT%C3%A9nisAAC" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>
			

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Tiro ao Arco -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="tiroarco" class="radius button">
					<img  src="img/desporto/tiro.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Tiro com Arco </h2>
				</div>

				<!--Tiro ao Arco-->
				<div id="tiroarco" class="reveal-modal" data-reveal>
				  <h2> Tiro com Arco </h2>
				  	<img class="img-desporto" src="img/desporto/tiro.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>Fundada em 1998, a Secção de Tiro com Arco da Associação Académica de Coimbra tem como objectivo principal a promoção da prática de tiro com arco e com besta. Para atingir este objectivo a secção promove o ensino da modalidade, realiza acções de divulgação, organiza provas e incentiva a participação de atiradores federados nos campeonatos nacionais e internacionais.</p>
				  	<p>A S.T.A. da A.A.C. é um dos clubes portugueses que organiza provas a contar para o Campeonato Nacional de Tiro de Caça organizado pela Federação de Arqueiros e Besteiros de Portugal (F.A.B.P.) e seguindo os regulamentos da International Field Archery Association (I.F.A.A.) para os campeonatos do mundo Bowhunter.</p>
				  	<p>Os treinos livres são às 4ªs-feiras à noite, das 21:30 às 23:00, no pavilhão de Karatê do Estádio Universitário de Coimbra.</p>
				  	<p>Atualmente a S.T.A. conta com cerca de 14 sócios ativos, sendo regularmente frequentada por entusiastas e curiosos.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>manuelssilva16@hotmail.com</p>
					<p>dani_cdfm@hotmail.com</p>
					<p>pmmfx@hotmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>O local de sede é o local e a hora dos treinos (o gabinete da secção no edifício da AAC é virtualmente inutilizado pela secção).</p>
					<a href="https://www.facebook.com/pages/Sec%C3%A7%C3%A3o-de-Tiro-com-Arco-da-Associa%C3%A7%C3%A3o-Acad%C3%A9mica-de-Coimbra/594268420637337?fref=ts" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->


			<!-- Triggers  Voleibol -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="voleibol" class="radius button">
					<img  src="img/desporto/voleibol.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Voleibol </h2>
				</div>

				<!--Voleibol-->
				<div id="voleibol" class="reveal-modal" data-reveal>
				  <h2> Voleibol </h2>
				  	<img class="img-desporto" src="img/desporto/voleibol.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O voleibol foi criado nos Estados Unidos, no dia 9 de fevereiro de 1895, pelo diretor de educação física da ACM (Associação Cristã de Moços de Massachusetts) William Morgan. A Associação cristã da Mocidade (A.C.M.), ramo português do Y.M.C.A., teve uma ação relevante na difusão do voleibol em Portugal e a ela se deve a publicação do primeiro livro de regras, bem como a sua contribuição para a fundação da Associação de Voleibol de Lisboa, que seria fundada em 28 de Dezembro de 1938. Em 8 de Abril de 1940 fundou-se em Coimbra a Associação de Voleibol de Coimbra.</p>
					<p>Em 1945 surge na Roménia o 1º selo dedicado ao Voleibol.</p>
					<p>O primeiro jogo entre o Porto e Lisboa, realizou-se em 23 de Junho de 1946, cabendo a vitória a Lisboa por 2-0.</p>
					<p>A Federação Portuguesa de Voleibol nasceu no dia 7 de Abril de 1947 em Lisboa, sendo presidida por Guilherme Sousa Martins. A F.P.V. seria uma das fundadoras da Federação Internacional de Voleibol. O primeiro Campeonato Nacional de Seniores Masculino disputou-se em 1946/47, tendo como vencedor o Técnico. A prova feminina apenas começou em 1959/60, com a equipa do S.C.</p>
					<p>Espinho a sagrar-se campeã nacional.</p>
					<p>A Federação Internacional de Voleibol (FIVB) é criada em 1947. O seu primeiro Congresso realiza-se em Paris de 18 a 20 de Abril e nele participam 14 Países: Bélgica, Brasil, Checoslováquia, França, Holanda, Israel, Itália, Líbano, Polónia, Portugal, Roménia, Turquia, Uruguai e Estados Unidos da América.</p>
					<p>A estreia da seleção portuguesa em provas internacionais deu-se no Campeonato da Europa de 1948 em Roma, acabando a prova em quarto lugar.</p>
					<p>Em 1949 em Praga teve lugar a primeira edição do Campeonato Mundial, ainda restrita à Europa e contando apenas com selecções masculinas, sendo vencedor a União Soviética.</p>
					<p>Em 1952, o Campeonato do Mundo teve a sua primeira versão feminina e foi disputado em Moscovo, tendo como vencedor a União Soviética. A participação de Portugal num mundial aconteceu em 1956 em Paris.</p>
					<p>O Voleibol participa pela primeira vez nos Jogos Olímpicos de Tóquio – 1964. No Torneio Olímpico Masculino com dez equipas, o vencedor é a URSS. No Torneio Olímpico Feminino com oito equipas, o vencedor é o Japão.</p>
					<p>A secção de Voleibol da AAC tem uma longa tradição de desporto amador e universitário remontando a sua fundação ao ano de 1942.
					<p>Em 1964/65 quando a Universidade contratou para treinar várias modalidades, incluindo o Voleibol, o Prof. José Brum, passou a haver treinos regulares e estruturados e iniciou-se a formação de jogadores. Este impulso teve bons resultados pelo que a equipa sénior da AAC foi Campeã Nacional da II divisão em 1966/67, 68/69, 70/71, 72/73 e 78/79. Em 74/75 alcançou o 4º lugar na 1ª divisão. Depois de um período menos bom devido a alterações no financiamento das secções, a secção de Voleibol fez um grande esforço para se manter activa e em 98/99 volta a ser Campeã Nacional da II divisão.</p>
					<p>Em 1999/00 a equipa sénior masculina B consegue o título Nacional da III divisão. Neste mesmo ano a equipa sénior Feminino ascendeu à I divisão A2 ficando em 2º lugar na época passada. Em 2001/02 a equipa sénior masculino ascende à I divisão A1, nível máximo da modalidade, onde consegue por 2 vezes um excelente 5º lugar. </p>
					<p>Em 2003/2004 representa Portugal numa poule da taça CEV (Confederação Europeia de Voleibol) na Alemanha tendo ficado em 4º lugar com os mesmos pontos do 2º classificado.</p>
					<p>Em 02/03 a equipa sénior feminina da secção foi Campeã Nacional Universitária. Em 2006/07 descemos à 1º divisão A2, onde ainda nos encontramos, agora denominada 2º Divisão.</p>
					<p>Na época 2010-2011 a equipa sénior masculina sagrou-se campeã Nacional Universitária, tendo ficado em 7º lugar no Campeonato Europeu na Sérvia. A equipa feminina conseguiu um 3º lugar.</p>
					<p>Em 2011-2012 os estudantes voltam a ser campeões nacionais universitários e em Córdoba no campeonato Europeu ficam em 6º lugar.</p>
					<p>Para a época 2012-2013 ambas as equipas Séniores masculina e feminina já garantiram a manutenção que era o principal objetivo da direcção.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  Xadrez -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="xadrez" class="radius button">
					<img  src="img/desporto/xadrez.png" onerror="this.src='notfound.png'" alt="secção desportiva">
					</a>
					<h2> Xadrez </h2>
				</div>

				<!--Xadrez-->
				<div id="xadrez" class="reveal-modal" data-reveal>
				  <h2> Xadrez </h2>
				  	<img class="img-desporto" src="img/desporto/xadrez.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>De origens perdidas nos meados do século XIX, e com mais de cem anos de actividade, a Secção de Xadrez da AAC (SXAAC) encontra-se num momento estável da sua história, mantendo a sua equipa principal há vários anos a disputar a Primeira Divisão Nacional de Xadrez.</p>
					<p>Nas duas últimas épocas, acabou como vice-campeã de Portugal. Melhor resultado da sua história.</p>
					<p>Na década de 90, devido ao acréscimo de praticantes da modalidade, foram criadas duas novas equipas dentro da SXAAC: A equipa “B” que milita na 2ª divisão (vice campeão na época 07-08) e a equipa “C” na Terceira Divisão Nacional. Neste momento, para além disso tem as equipas “D” e “E” que jogam nos distritais.</p>
					<p>Também participa, por vezes, no Desporto Universitário, onde já foi Campeã Nacional Universitária.</p>
					<p>Do mesmo modo, também os jogadores da SXAAC participam individualmente em torneios, em representação da Academia.</p>
					<p>A SXAAC não tem apenas motivações competitivas. Vem sendo desenvolvido, há mais de 15 anos, um projecto de aprendizagem de xadrez destinado a crianças e jovens e cursos de xadrez para estudantes universitários que queiram aprender esta modalidade.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				</div>
			</div>
		</div>

	</section>
<!-- .................................................................................... -->
	
<!-- FOOTER -->
	<?php
		include 'footer.html';
	?>
<!-- ..................... -->
    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>

</body>


</html>