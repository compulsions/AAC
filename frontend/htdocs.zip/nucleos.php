<!DOCTYPE html>
<html>
<head>
	<title>Associação Académica de Coimbra</title>

     <meta charset="utf-8">
	<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/font-awesome.min.css" rel="stylesheet" media="screen">
    <link href="css/style.css" rel="stylesheet" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,300,100,700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <link href="img/favicon.png" rel="shortcut icon">
    <link rel="stylesheet" href="css/flickity-docs-slide.css" media="screen" />
    <link rel="stylesheet" href="css/lightbox.css" media="screen" />

    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>

    <script src="js/jquery.min.js"></script>
    <script src="js/flickity-docs.min.js"></script>
    <script src="js/lightbox.min.js"></script>
    <script src="js/randomcores.js"></script>
   
</head>
<body >
	<header style="margin-bottom:10px;" class="branco">
		<div class="container titulo">
			<div class="aac">
				<div class="col-md-1 col-sm-1 col-xs-12">
					<a href="index.php">
						<img src="img/aac2.png" alt="aac"> 
					</a> 
				</div>
				<div class="col-md-11 col-sm-10 col-xs-12 txt">
					| Associação Académica de Coimbra 
				</div>	
			</div> 
		</div>
		
	</header>
<!-- NAVBAR -->
	<?php
		include 'navbar.html';
	?>
<section>
<!--............................  SLIDESHOW + CALENDARIO................................. -->
	<?php
		include 'slideshow.html';
	?>
<!-- .................................................................................... -->
</section>
<!--............................  SECTION DE BASE................................. -->
	<section>
		<div class="container cor">
			<div class="tituloPag"> Núcleos</div>
			<div class="info  nucleos">
				<!-- Triggers  NEA antropologia -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEA" class="radius button">
					<img  src="img/nucleos/nea.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEA / AAC </h2>
				</div>

				<!-- NEA -->
				<div id="NEA" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Antropologia</h2>
				  	<img style="width:30%;" src="img/nucleos/nea.png"  onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>
				  	Com 11 anos de existência, o Núcleo de Estudantes de Antropologia é o organismo que representa os estudantes de Antropologia junto da Associação Académica de Coimbra. Ao longo do ano o NEA/AAC promove um conjunto de actividades desportivas, culturais e formativas procurando desta forma, oferecer a todos os estudantes oportunidades de confraternização e de enriquecimento pessoal.</p>
					<p>Além do já mencionado, o NEA/AAC encontra-se sempre disponível para responder a qualquer dúvidas ou solicitações.
					</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nea_fctuc @hotmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Colégio de S.Bento – Coimbra</p>
					<a href="https://www.facebook.com/neafctuc" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  N  administração publico privada-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEAPP" class="radius button">
					<img src="img/nucleos/neapp.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEAPP / AAC </h2>
				</div>

				<!-- NEAPP -->
				<div id="NEAPP" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Administração Público Privada</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/neapp.png" alt="nucleo">
				  	<p>
				  	O NEAPP/AAC sediado no Palácio dos Melos representa a Licenciatura em Administração Público Privada, o Mestrado em Administração Pública e o Mestrado em Administração Pública Empresarial constituídos com cerca de 250 estudantes. </p>
					<p>O NEAPP/AAC tem como objetivo primordial a representação e defesa dos direitos dos seus estudantes. Para além da sua habitual Direção e Mesa de Plenário, possui os seus Pelouros da Pedagogia, Cultura, GAPE, Saídas Profissionais, Relações Externas e Comunicação e Imagem que em conjunto trabalham para o bem-estar e futuro desenvolvimento profissional dos seus estudantes.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>neappaac@gmail.com</p>
					<a href="https://www.facebook.com/neappcoimbra" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEB biologia-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEB" class="radius button">
					<img  src="img/nucleos/neb.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEB / AAC </h2>
				</div>

				<!-- NEB -->
				<div id="NEB" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Biologia</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/neb.png" alt="nucleo">
				  	
				  	<p>
				  	Pertencendo à maior e mais antiga associação académica do País, o Núcleo de Estudantes de Biologia da Associação Académica de Coimbra é um dos 26 núcleos da AAC e representa mais de 700 alunos da Universidade de Coimbra divididos entre os seguintes: </p>
					<p>•	Licenciatura em Biologia;</p>
					<p>•	Licenciatura em Biologia + Menor;</p>
					<p>•	Mestrado em Biodiversidade e Biotecnologia Vegetal;</p>
					<p>•	Mestrado em Biologia;</p>
					<p>•	Mestrado em Biologia e Geologia;</p>
					<p>•	Mestrado em Biologia Celular e Molecular;</p>
					<p>•	Mestrado em Ecologia;</p>
					<p>•	Doutoramento em Biociências.</p>
					<p>O NEB/AAC tem como principais objetivos o progresso nas saídas profissionais e pedagogia dos nossos estudantes, a integração dos mesmos nas mais variadíssimas atividades de interesse promovidos pela Faculdade, Associação Académica e outros, divulgação e prestação de todos os possíveis apoios a projetos de interesse coletivo (estágios, palestras, seminários) e fomentar a inter-relação e convívio entre comunidade académica.
					</p>
					<a href="site" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEQ quimica-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEQ" class="radius button">
					<img  src="img/nucleos/neq.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEQ / AAC </h2>
				</div>

				<!-- NEQ -->
				<div id="NEQ" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Química</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/neq.png" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Química da Associação Académica de Coimbra, NEQ/AAC, foi fundado a 15 de Abril de 1999, representa os cerca de 300 alunos das Licenciaturas em Química e Química Medicinal, dos Mestrados de Química, Química Forense e Química Medicinal e do Doutoramento em Química e mantém um papel activo na vida académica coimbrã e na luta por um Ensino Superior melhor e generalizado. O NEQ/AAC procura fomentar o contacto entre os alunos de Química de Portugal, tendo, em Março de 2013, tomado a iniciativa de organizar o I Encontro Nacional de Estudantes de Química (ENEQUI) e de fundar a Associação Nacional de Estudantes de Química.</p>
					<p>Tem como eventos de maior impacto mediático a sua Gala de Solidariedade do Departamento de Química que acontece sempre em Dezembro e atribui milhares de euros a instituições de cariz solidário, o Mega Convívio Átrio das Químicas que acontece uma vez por semestre e junta milhares de estudantes no emblemático Átrio das Químicas e mais recentemente a Feira de Emprego e Empreendedorismo do Departamento de Química que permite mostrar a amplitude de ofertas que esta área do saber tem.</p>
					<p>O NEQ/AAC tem sede no Departamento de Química da Faculdade de Ciências e Tecnologia da Universidade de Coimbra, DQ-FCTUC, no Piso B, e mantém ainda uma sala de estudo no Piso C, em frente à biblioteca, onde os estudantes do Departamento podem estudar ou fazer trabalhos de grupo.
					</p>

					<br>
					<p><b>Contacto:</b></p>
					<p>	geral@neqaac.org</p>
					<a href="http://www.facebook.com/nequiaac" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://www.neqaac.org" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEBIOQ bioquimica-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEBIOQ" class="radius button">
					<img  src="img/nucleos/nebioq.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEBIOQ / AAC </h2>
				</div>

				<!-- NEBIOQ -->
				<div id="NEBIOQ" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Bioquímica</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/nebioq.png" alt="nucleo">
				  	<p>
				  	O Núcleo de Estudantes de Bioquímica da Associação Académica de Coimbra (NEBIOQ/AAC) surgiu no ano de 1999, enquadrado numa tentativa de aproximação da AAC aos Estudantes, devido ao aumento colossal do número de alunos após o 25 de Abril de 1974.</p>
					<p>O NEBIOQ/AAC passou adquirir competências na representação de todos os Estudantes de Licenciatura e Mestrado em Bioquímica, defendendo todos os seus direitos e interesses, e sendo o seu elo de ligação. Ao longo dos anos, este núcleo foi desenvolvendo diversas acções em prol dos Estudantes, sendo elas divididas em várias áreas de trabalho, como: Pedagogia, Saídas Profissionais, Relações Externas, Comunicação e Imagem, Cultura, Desporto e Intervenção Cívica e Ambiente.</p>
					<p>Poderão acompanhar os nossos trabalhos no Departamento de Ciências da Vida e encontrar-nos no edifício do Colégio das Artes (Ex-Departamento de Bioquímica).<p>

					<br>
					<p><b>Contacto:</b></p>
					<p>nebioq@gmail.com</p>
					<p><b>Localização:</b></p>
					<p>Departamento de Ciências da Vida • FCTUC Apartado 3046 | 3001-401 Coimbra</p>
					<a href="http://www.facebook.com/nebioqaac" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NG GEOCIENCIAS-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NG" class="radius button">
					<img  src="img/nucleos/ng.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NG / AAC </h2>
				</div>
				<!-- NG -->
				<div id="NG" class="reveal-modal" data-reveal>
				  <h2>Núcleo Geociências</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/ng.png" alt="nucleo">
				  	<p>Representa cerca de 250 alunos, licenciatura em geologia seu mestrados e doutoramentos.<p>
					<br>
					<p><b>Localização:</b></p>
					<p>Departamento de Ciências da Terra  FCTUC polo 2, piso 0</p>
				

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NED DIREITO-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NED" class="radius button">
					<img  src="img/nucleos/ned.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NED / AAC </h2>
				</div>
				<!-- NED -->
				<div id="NED" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Direito</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/ned.png" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Direito da Associação Académica de Coimbra é uma estrutura representativa dos, aproximadamente, 3000 estudantes de Direito da Universidade de Coimbra - da Licenciatura, passando pelos diversos cursos de Mestrado e de Doutoramento.<p>
				  	<p>O NED/AAC foi fundado há 15 anos, no ano de 2000, dando forma a estruturas inominadas que vinham, sem corpo organizatório estável, dando voz a algumas preocupações dos estudantes de Direito da FDUC - as comissões de curso e, no ano lectivo de 1999/2000, a comissão instaladora.</p>
				  	<p> Desde o seu nascimento, tem-se observado um crescimento exponencial das suas áreas de abrangência e de modos de aproximação aos estudantes. Actualmente o NED/AAC ramifica-se, além dos tradicionais pelouros da Pedagogia e das Saídas Profissionais, em Relações Externas, Gabinete de Apoio ao Estudante (GAPE), Desporto, Cultura, Gabinete Comunicação e Imagem, Recreativo, Relações Internacionais e Formação. </p>
				  	<p>Aberto todos os dias úteis, das 10 horas às 18 horas, o NED/AAC presta apoio directo aos estudantes através de ferramentas como Banco de Exames, Banco de Legislação, Banco de Manuais, Guia das Unidades Curriculares isoladas e venda de Códigos; tem promovido inúmeras actividades com objectivo de complementaridade quer da formação curricular (Cursos de Propriedade Intelectual e de Direito da Concorrência, Julgamentos in loco, Recursos no Processo Civil, etc.), quer da formação extracurricular (visitas aos museus da cidade, debates político-ideológicos) dos alunos de Direito.</p>
				  	<p>Ao longo dos anos o NED/AAC tem alcançado inúmeras conquistas, dando resposta às mais prementes preocupações dos estudantes, como por exemplo, o direito a critérios de correcção, a mostra de provas, prazos mais justos entre exames (orais e escritos) e, mais recentemente, através da sensibilização aos docentes, o aumento do número de unidades curriculares com regime de avaliação repartida.</p>
				  	<p>Além disso tem estimulado a aproximação ao mercado de trabalho e aos futuros empregadores, auxiliando também na transição entre ciclos de estudos - nomeadamente com a Feira de Mestrados, com o ProIus (feira de emprego), com as Sessões de Esclarecimentos da Ordem dos Advogados, o Fórum de Políticas de Emprego e o Guia das Saídas Profissionais. Por fim, é ainda de salientar a recente edição da primeira Revista Jurídica feita inteiramente de estudantes para estudantes, a Doctrina Nova, à venda por todo o país.</p>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!-- ..........................   -->

				<!-- Triggers  NEDF departamento de fisica-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEDF" class="radius button">
					<img  src="img/nucleos/nedf.jpg" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEDF / AAC </h2>
				</div>
				<!-- NEDF -->
				<div id="NEDF" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes do Departamento de Física</h2>
				  	<img style="width:30%;" onerror="this.src='notfound.png'" src="img/nucleos/nedf.jpg" alt="nucleo">
				  	<p>O número de estudantes que frequenta a Universidade de Coimbra tem vindo a aumentar ano após ano. Isto implicou que a Associação Académica de Coimbra, maior e mais prestigiada Associação de Estudantes do país, se organizasse de diferente forma. Começaram então a aparecer Núcleos de Estudantes nas várias Faculdades e Departamentos.</p>
					<p>Foi a 27 de Maio de 2003 que um grupo de 18 corajosos, como eu e tu, liderados por Lúcia Birlo formaram o então Núcleo de Estudantes de Física e Engenharia Física da Associação Académica de Coimbra (NEFEF/AAC).</p>
					<p>Em 2004, com o aparecimento do curso de Engenharia Biomédica no Departamento de Física, passámos a ser o Núcleo de Estudantes do Departamento de Física da Associação Académica de Coimbra (NEDF/AAC).</p>
					<p>Actualmente representamos cerca de 520 estudantes dos cursos de Física, Engenharia Física e Engenharia Biomédica da Universidade de Coimbra.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>geral@nedf.org</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Sala B.13 do Departamento de Física da Faculdade de Ciências e Tecnologia da Universidade de Coimbra, Rua Larga, 3004-516 Coimbra</p>
					<br>
					<a href="https://www.facebook.com/aac.nedf?_rdr" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="http://www.nedf.org" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers the NEI -->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEI" class="radius button">
					<img src="img/nucleos/nei.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEI / AAC </h2>
				</div>

				<!-- NEI -->
				<div id="NEI" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Informatica</h2>
				  	<img style="width:30%;" src="img/nucleos/nei.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O NEI/AAC (Núcleo de Estudantes de Informática da Associação Académica de Coimbra) é um órgão integrante da AAC que tem o propósito de representar os estudantes de Engenharia Informática e Design e Multimédia da Universidade de Coimbra, sócios da AAC.</p>
				  	<p>Fundado a 24 de Abril de 1997, o NEI está sediado no edifício do Departamento de Engenharia Informática onde mantém uma proximidade a todas as situações emergentes, procurando sempre apoiar e ajudar a resolver todas as necessidades dos estudantes do Departamento. Para tal, o NEI mantém uma forte ligação quer com alunos quer com os orgãos do Departamento proporcionando uma fácil comunicação entre ambos.</p>
				  	<p>Um dos princípios fundamentais do NEI é enriquecer a experiência dos estudantes do Departamento de Engenharia Informática durante a sua permanência na Universidade de Coimbra a diversos níveis. Com este objectivo em vista, o NEI organiza regularmente actividades Culturais, Desportivas, Recreativas e Formativas, divulga e presta apoio na organização de outros eventos e promove diferentes espaços de uso livre.</p>
				
					<br>
					<p><b>Contacto:</b></p>
					<p>nei@academica.pt</p>
					<p>nei.academica@gmail.com</p>
					<p>239 790 002</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Sala C4.3 (Torre C)
					Departamento de Engenharia Informática
					Faculdade de Ciências e Tecnologia da Universidade de Coimbra
					Pólo II - Pinhal de Marrocos
					3030-290 Coimbra</p>
					<a href="https://www.facebook.com/neiaac" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://nei.dei.uc.pt" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!-- ..........................   -->

				<!-- Triggers  NEEC ENG.CIVIL-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEEC" class="radius button">
					<img  src="img/nucleos/neec.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEEC / AAC </h2>
				</div>

				<!-- NEEC-->
				<div id="NEEC" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Engenharia Civil</h2>
				  	<img style="width:30%;" src="img/nucleos/neec.png" onerror="this.src='notfound.png'" alt="nucleo">
				 	<p>
				  	O Núcleo de Estudantes de Engenharia Civil da Associação Académica de Coimbra (NEEC/AAC) foi fundado em 2000 representando actualmente todos os estudantes de Engenharia Civil da Universidade de Coimbra.</p>
					<p>Estabelece a ligação entre a DG/AAC e os estudantes que representa, realizando actividades em diversas áreas como as Saídas Profissionais, Pedagogia, Desporto ou Cultura. Presta também auxilio aos estudantes em questões pedagógicas e em questões relacionadas com o Programa Erasmus, entre outros.</p>
					<p>O NEEC tem por seu principal objectivo ajudar os colegas de curso nos demais problemas e organizar actividades e eventos que tornem o curso mais interessante e fomentem o desenvolvimento pessoal e curricular dos estudantes de Engenharia Civil.<p>
					<p>Assim, desde sempre este núcleo esteve muito próximo dos estudantes, tornando-se num local onde podem expor as suas dúvidas e críticas quanto a assuntos de dentro e fora da faculdade. O núcleo vê como seu interesse os problemas de qualquer estudante, servindo também de ponte entre os colegas e os docentes em assuntos pedagógicos ou relacionados com o Mestrado Integrado em Engenharia Civil (MIEC).</p>
					<p>Muito mais que um organizador de eventos, este grupo de estudantes vê como finalidade ajudar os colegas a desenvolverem-se a nível extra-curricular e a estarem alerta quanto aos assuntos actuais da Engenharia Civil.<p>
					<br>
					<p><b>Contacto:</b></p>
					<p>neecivil@gmail.com</p>
					<p>239 797 168</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Departamento de Eng. Civil da FCTUC Rua Luís Reis Santos Pólo II da Universidade 3030-788 Coimbra PORTUGAL</p>
					<a href="http://www.facebook.com/neecaac" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://www.neecaac.com" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

					<a href="http://www.facebook.com/pilar.neec" target="_blank;">
					<i class="fa fa-newspaper-o fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEFLUC faculdade de letras da uc-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEFLUC" class="radius button">
					<img  src="img/nucleos/nefluc.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEFLUC / AAC </h2>
				</div>
				<!-- NEFLUC -->
				<div id="NEFLUC" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes da Faculdade de Letras da Universidade de Coimbra</h2>
				  	<img style="width:30%;" src="img/nucleos/nefluc.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O Núcleo de Estudantes da Faculdade de Letras da Universidade de Coimbra (Nefluc/AAC) é o maior núcleo da Associação Académica de Coimbra e tem a responsabilidade de representar mais de 3.000 alunos, de 13 licenciaturas distintas e mais de 30 outros cursos de ciclos de estudo.</p>
					<p>Assim, a nossa Faculdade é constituída por uma pluralidade de saberes que vai desde o passado da História ao futuro dos meios de comunicação e do Jornalismo, das Línguas Modernas aos Estudos Clássicos, das Letras às Artes. Cruzar nos corredores ciências e conhecimentos tão distintos, que nos permite gerar uma conjugação única, é das nossas mais-valias, ao mesmo tempo que nos lança o dilema de gerar e conceber uma identidade única. É essa uma das atuais e mais importantes missões do Nefluc/AAC, que pugnará sempre por uma Faculdade de Letras solidária, eficiente e unificada, com uma identidade singular apesar da sua diversidade de saberes, ao mesmo tempo em que nos comprometemos a ser mais úteis, mais interventivos e mais conscientes da função que temos a desempenhar.</p>
					<p>Somos um grupo de estudantes que tem a particularidade de agregar a experiência associativa, à irreverência, à criatividade e à determinação de fazer mais e melhor de forma voluntária, porque a experiência do Ensino Superior é bem mais do que cumprir o plano de estudos de um curso.<p>
					<p>A nossa equipa abrange 12 áreas distintas que se completam simultaneamente e teremos todo o gosto que te juntes a nós na procura de estratégias que ajudem a complementar e potenciar as capacidades dos alunos desta casa, tanto a nível académico como pessoal, organizando e promovendo atividades de cariz cultural, social, pedagógico, desportivo, cívico e recreativo.</p>
					<p>Contem connosco a vosso lado nesta caminhada, mas sobretudo juntem-se a nós, deixem também a vossa marca através de projetos, atividades e convicções, para que possamos responder prontamente às necessidades diárias dos nossos colegas.<p>
					<p>Precisamos da tua ajuda para chegar mais longe!</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nefluc@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Gabinete de Apoio ao Estudante, 4º piso</p>
					<a href="https://www.facebook.com/nefluc?fref=ts" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEMAT matematica-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEMAT" class="radius button">
					<img  src="img/nucleos/nemat.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEMAT / AAC </h2>
				</div>
				<!-- NEI -->
				<div id="NEMAT" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Matemática </h2>
				  	<img style="width:30%;" src="img/nucleos/nemat.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>
				  	O Núcleo de Estudantes de Matemática é um organismo da Associação Académica de Coimbra com uma história que remonta aos anos 80. </p>
					<p>Desde sempre activo e dinâmico, representa todos os estudantes matriculados em ciclos de estudos do Departamento de Matemática da Universidade de Coimbra espalhados por uma Licenciatura em Matemática, 6 Mestrados e Doutoramentos.</p>
					<p>Tem também como função o desenvolvimento de actividades lúdicas e pedagógicas que visam a integração dos seus estudantes na vida coimbrã, bem como na realidade profissional do mercado.<p>
					<p>Actualmente, o NEMAT/AAC representa mais de 200 estudantes.<p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nemat.aac@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Sala 4.4 do DMUC Departamento de Matemática da FCTUC / Apartado 3008 / EC Santa Cruz / 3001 – 501 Coimbra</p>
					<a href="http://www.facebook.com/Nemataac" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NUDA NUCLEO DE ARQUITECTURA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NUDA" class="radius button">
					<img  src="img/nucleos/nuda.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NUDA / AAC </h2>
				</div>
				<!-- NEI -->
				<div id="NUDA" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Arquitectura</h2>
				  	<img style="width:30%;" src="img/nucleos/nuda.png" onerror="this.src='notfound.png'" alt="nucleo">
				    <p>O NUDA (Núcleo de Estudantes de Arquitetura) desenvolve diversas iniciativas nas quais os alunos podem participar ou dinamizar como complemento à formação académica. A revista NU, editada por estudantes e para estudantes, é uma proposta do NUDA, lançada regularmente, que reflete de uma forma teórica o mundo da arquitetura (dentro de um departamento para o mundo).</p>
					<p>O Jornal, criado recentemente, junta alunos de diversos anos com a iniciativa de agitar as mentes, de forma a trazer sempre à discussão temas atuais entre estudantes, docentes e investigadores.</p>
					<p>É também divulgada todos os meses, via facebook, uma newsletter informativa de todos os eventos que serão organizados pelo núcleo.</p>
					<p>Viajar é essencial para cruzar culturas e experiências, como tal, vital para um jovem arquiteto ver novas/diferentes formas de construir ou desenhar a arquitetura, para criar a sua própria identidade. Assim, é também do maior interesse do núcleo a dinamização de viagens organizadas por diferentes cidades.<p>
					<p>O DARQ e o NUDA colocam-se assim numa posição distinta com uma proposta completa para cada estudante, para as suas necessidades e objectivos, interligando-se com outros contextos e realidades.<p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nudaac@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Núcleo de Estudantes de Arquitectura (NuDA)
					Departamento de Arquitectura da Universidade de Coimbra
					Colégio das Artes, Largo D. Dinis 
					3000 Coimbra, Portugal</p>
					<a href="http://www.facebook.com/nudaac?fref=ts" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEEA ENG AMBIENTE-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEEA" class="radius button">
					<img  src="img/nucleos/neea.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEEA / AAC </h2>
				</div>
				<!-- NEEA -->
				<div id="NEEA" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Engenharia do Ambiente</h2>
				  	<img style="width:30%;" src="img/nucleos/neea.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Engenharia do Ambiente da AAC surge pela necessidade de dar aos estudantes de Engenharia do Ambiente da FCTUC uma resposta mais ativa, eficaz e completa sobre os seus problemas. E é deste modo que se caracteriza por uma grande proximidade aos estudantes que representa. Proporciona inúmeras atividades culturais, lúdicas e desportivas para potencializar relações entre os seus estudantes e também a restante comunidade estudantil. Sem deixar de parte os verdadeiros problemas de um estudante, tenta acompanhar os problemas pedagógicos e oferecer mais oportunidades da área das saídas profissionais.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>neea.aac@gmail.com </p>
					<br>
					<p><b>Localização:</b></p>
					<p>Faculdade de Ciências e Tecnologias da Universidade de Coimbra Departamento de Engenharia Civil Pólo II - Rua Luís Reis Santos  3030-778 Coimbra, Portugal</p>
					<a href="https://www.facebook.com/neeaaac/info?tab=page_info" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEDEQ  DEP ENG QUIMICA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEDEQ" class="radius button">
					<img  src="img/nucleos/nedeq.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEDEQ / AAC </h2>
				</div>
				
				<!-- NEDEQ -->
				<div id="NEDEQ" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes do Departamento de Engenharia Química</h2>
				  	<img style="width:30%;" src="img/nucleos/nedeq.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O NEDEQ/AAC – Núcleo de Estudantes do Departamento de Engenharia Química da Associação Académica de Coimbra – é o órgão representativo dos Estudantes de Engenharia Química da FCTUC, no seio da AAC.</p>
					<p>O NEDEQ/AAC tem como fim a cooperação na resolução de questões pedagógicas promovendo um melhor ensino, a aquisição de competências extracurriculares que potenciam melhores profissionais e a dinamização de actividades culturais, lúdicas e desportivas.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nedeq@academica.pt</p>
					<br>
					<a href="https://www.facebook.com/NEDEQAAC?_rdr" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!-- ..........................   -->
				<!-- Triggers  NEF ESTUDANTES DE ECONOMIA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEE" class="radius button">
					<img  src="img/nucleos/nee.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEE / AAC </h2>
				</div>
				<!-- NEE -->
				<div id="NEE" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Economia</h2>
				  	<img style="width:30%;" src="img/nucleos/nee.png" onerror="this.src='notfound.png'" alt="nucleo">
					<p>O Núcleo de Estudantes de Economia da Associação Académica de Coimbra (NEE/AAC), enquanto braço da Associação Académica de Coimbra, é o representante dos estudantes de Economia da Faculdade de Economia da Universidade de Coimbra.</p>
				  	<p>A imagem do NEE/AAC, organização que celebra, em breve, 16 anos de existência, está associada ao crescimento e progresso, sustentável e seguro, que têm caracterizado os sucessivos mandatos dos estudantes que a ele têm dedicado a sua disponibilidade.</p>
				  	<p>A presença do NEE/AAC tem-se evidenciado no contributo à integração de novos estudantes, na organização de eventos de natureza recreativa e desportiva, na promoção da cultura e tradição Coimbrã bem como no desenvolvimento quer de atividades de cariz solidário quer de atividades capazes de proporcionar experiências políticas e pedagógicas a fim de fomentar a preparação dos estudantes para o período pós-licenciatura.</p>
				  	<p> Hoje em dia, o NEE/AAC não só representa todos os estudantes de Economia junto da licenciatura em Economia, da Direção da Faculdade de Economia e da Associação Académica de Coimbra através dos órgãos próprios para o efeito, como também constitui, ele próprio, pólo dinamizador e fonte de proactividade junto da comunidade, em geral, e dos seus estudantes, em particular.</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Avenida Dias da Silva nº165  3004-512 Coimbra</p>
					<a href="https://www.facebook.com/NEEAAC?fref=ts" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEEEC ENG ELECTROTECICA E DE COMPUTADORES-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEEEC" class="radius button">
					<img  src="img/nucleos/neeec.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEEEC / AAC </h2>
				</div>
				<!-- NEEEC -->
				<div id="NEEEC" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Engenharia Electrotécnica de Computadores </h2>
				  	<img style="width:30%;" src="img/nucleos/neeec.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Engenharia Electrotécnica e de Computadores da Associação Académica de Coimbra existe com o propósito de representar todos os estudantes do curso, lutando pelos seus direitos e deveres. A nossa missão passa por integrar todo e qualquer estudante na realidade académica, pedagógica, cultural, desportiva e associativa em que se insere, e que inevitavelmente passa por Coimbra.</p>
				  	<p>Fundado a 31 de Março de 1998, o NEEEC/AAC é o elo de ligação entre professores e alunos, entre os estudantes e a Associação Académica de Coimbra.  A magia do núcleo é não estarmos sozinhos. Aparece!</p><br>
				  	<p><b>Contacto:</b></p>
					<p>neeec.aac.uc@gmail.com</p>
					<p>Pedagogia: pedagogiadeec@gmail.com</p> 
					<p>Saídas Profissionais: sp.neeec@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Faculdade de Ciências e Tecnologias da Universidade de Coimbra
					Departamento de Engenharia Electrotécnica e de Computadores
					Pólo II, Pinhal de Marrocos 
					3030-290 Coimbra </p>
					<a href="https://www.facebook.com/AAC.NEEEC" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEEM  ENG MECANICA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEEM" class="radius button">
					<img  src="img/nucleos/neem.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEEM / AAC </h2>
				</div>
				<!-- NEEM -->
				<div id="NEEM" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Engenharia Mecânica</h2>
				  	<img style="width:30%;" src="img/nucleos/neem.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>Núcleo de Estudantes do Departamento de Engenharia Mecânica da Universidade de Coimbra. Fundado em 1998, representa os estudantes de Engenharia Mecânica e de Engenharia e Gestão industrial.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>neemaac@gmail.com</p>
					<p>239 790 780</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Pinhal de Marrocos, Pólo II da UC</p>
					<a href="https://www.facebook.com/neemaac.oficial?fref=ts" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://www2.dem.uc.pt/neemaac/" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEF-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEF" class="radius button">
					<img  src="img/nucleos/nef.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEF / AAC </h2>
				</div>
				<!-- NEF -->
				<div id="NEF" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Farmácia</h2>
				  	<img style="width:30%;" src="img/nucleos/nef.png" onerror="this.src='notfound.png'" alt="nucleo">  	
					<p>O Núcleo de Estudantes de Farmácia da Associação Académica de Coimbra (NEF/AAC) surgiu em Novembro de 1986 enquanto estrutura representativa dos estudantes da Faculdade de Farmácia da Universidade de Coimbra (FFUC). É também um dos núcleos mais antigos da Associação Académica de Coimbra (AAC) e membro fundador da Associação Portuguesa de Estudantes de Farmácia (APEF).</p>
					<p>Actualmente representa cerca de 1400 estudantes, desde alunos do Mestrado Integrado em Ciências Farmacêuticas (MICF), das Licenciaturas em Ciências Bioanalíticas (LCB) e em Farmácia Biomédica (LFB) aos diversos mestrados e doutoramentos existentes na FFUC.</p>
					<p>O NEF/AAC tem uma estrutura assente numa fluente dinâmica em interligação com a DG/AAC, assegurando a representação de todos os estudantes da FFUC, quer internamente, na própria academia, quer externamente, na APEF.</p>
					<p>Fazendo parte de uma universidade com mais de setecentos anos e de uma Associação Académica com cento e vinte e cinco, marcada pela irreverência estudantil, em busca da sua liberdade, bem como por um desenvolvimento científico e cultural sem igual, é nosso dever promover e fomentar uma participação activa, num trajecto que apesar de vários percalços se tem composto de história e conquistas.</p>
					<p>Numa época que muito conturbada se apresenta, pautamos por especial atenção aos diversos problemas com que o ensino superior e, consequentemente, os nossos estudantes se têm deparado, quer a nível de acção social e abandono escolar, quer a nível pedagógico e saídas profissionais, fazendo tudo o que estiver ao nosso alcance para os solucionar.</p>
					<p>Por diversas razões, entre as quais algumas apresentadas anteriormente, todos sabemos que o futuro nada fácil se avizinha, mas acreditamos que a mudança e construção deste deverá ser feita por aqueles que são o Futuro do País. Neste sentido, de olhos postos no passado, entendendo todos os erros que cometemos e desenvolvendo o que de bem tem sido feito, construiremos esse Futuro.</p>
					<p>Um Futuro não nosso, mas de cada um de nós.</p>				
					<br>
					<p><b>Contacto:</b></p>
					<p>geral@nefaac.pt</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Faculdade de Farmácia da Universidade de Coimbra, Pólo das Ciências da Saúde, Azinhaga de Santa Comba, 3000-548 Coimbra</p>
					<a href="https://www.facebook.com/nefaacoimbra" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://www.nefaac.pt" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!-- ..........................   -->
				<!-- Triggers  NEG GESTAO-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEG" class="radius button">
					<img  src="img/nucleos/neg.png"  onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEG / AAC </h2>
				</div>
				<!-- NEG -->
				<div id="NEG" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Gestão</h2>
				  	<img style="width:30%;" src="img/nucleos/neg.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Gestão da Associação Académica de Coimbra celebra, em 2015, dez anos de existência, dez anos de luta e de defesa pelos interessentes de todos os estudantes de Gestão da Faculdade de Economia da Universidade de Coimbra. São 10 anos de um trabalho constante, que se revela através do envolvimento desta comunidade estudantil.</p>
				  	<p>A universidade não educa só as pessoas numa determinada área científica, ela também tem o papel de nos formar enquanto seres humanos. E a missão do NEG assenta essencialmente nisso mesmo, na formação e auxílio dos estudantes, através de uma preocupação constante acerca das necessidades dos mesmos. Pois, sendo um núcleo ativo, presente e comprometido, pretende contribuir para a valorização do percurso académico dos estudantes.</p>
				  	<p>O NEG aposta na receção aos novos alunos, ajudando-os na difícil fase de transição entre o ensino secundário e o superior, na promoção de atividades de integração e de conhecimento, assim como atividades desportivas, académicas e lúdicas, que promovam o bem-estar e sentido de pertença. Aposta também na promoção da faculdade fora de portas, junto de escolas e empresas, divulgando deste modo a vasta oferta formativa que a mesma oferece e as qualidades que detém.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>geral@negaac.info</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Av. Dr. Dias da Silva, Nº 165  3004- 512 Coimbra</p>
					<a href="https://www.facebook.com/NEGAACpage" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://negaac.wix.com/site" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!-- ..........................   -->

				<!-- Triggers  NEM MEDICINA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEM" class="radius button">
					<img  src="img/nucleos/nem.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEM / AAC </h2>
				</div>
				<!-- NEI -->
				<div id="NEM" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Medicina</h2>
				  	<img style="width:30%;" src="img/nucleos/nem.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Medicina da Associação Académica de Coimbra (NEM/AAC) assume-se,desde 1998, como representante institucional de todos os Alunos de Mestrado Integrado em Medicina da Faculdade de Medicina da Universidade de Coimbra, sendo parte integrante da secular Academia Coimbrã.</p>
				  	<p>Com uma vasta área de atuação, tem como objetivo geral complementar a formação médica, potenciando as capacidades dos alunos da escola médica de Coimbra. Através da organização e promoção de atividades de cariz científico, cultural, cívico, pedagógico, desportivo e recreativo, oferece insubstituíveis oportunidades de formação humana e académica.</p>
				  	<p>Para além da intervenção na formação dos alunos, é de destacar o papel cívico que o NEM/AAC tem vindo a desenvolver na cidade de Coimbra, em Portugal e fora do nosso país. O Hospital do Ursinho, o Convida os Avós, o congresso médico-científico In4Med são já um fator de reconhecimento do nosso núcleo.</p>
				  	<p>O NEM/AAC é ainda o representante dos Estudantes de Medicina de Coimbra, à escala nacional, no seio da Associação Nacional de Estudantes de Medicina (ANEM/PorMSIC), federação que agrega os representantes dos estudantes de todas Escolas Médicas do país, e que nos contextualiza no espetro internacional.</p>
				  	<p>Através da ANEM, o NEM/AAC é membro da IFMSA (International Federation of Medical Students Associations) - uma ONG não política e sem fins lucrativos, que congrega associações de estudantes de medicina de países de todo o mundo, sendo um fórum internacional de Estudantes Médicos, reconhecido pela OMS, ONU, UNESCO e UNICEF.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>geral@nemaac.net</p>
					<br>
					<p><b>Localização:</b></p>
					<p>NÚCLEO DE ESTUDANTES DE MEDICINA DA ASSOCIAÇÃO ACADÉMICA DE COIMBRA
					Pólo das Ciências da Saúde
					Unidade Central, Piso -1
					Azinhaga de Santa Comba, Celas
					3000-548 Coimbra</p>
					<a href="https://www.facebook.com/nem.academica" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>

					<a href="http://nemaac.net" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>

				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->

				<!-- Triggers  NEMD MEDICINA DENTARIA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEMD" class="radius button">
					<img  src="img/nucleos/nemd.jpg" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEMD / AAC </h2>
				</div>
				<!-- NEMD -->
				<div id="NEMD" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Medicina Dentária</h2>
				  	<img style="width:30%;" src="img/nucleos/nemd.jpg"  onerror="this.src='notfound.png'" alt="nucleo">
				  










				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NEPCESS PSICOLOGIA, CIENCIAS DA EDUCAÇÃO E SERVIÇO SOCIAL-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NEPCESS" class="radius button">
					<img  src="img/nucleos/nepcess.jpg" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NEPCESS / AAC </h2>
				</div>
				<!-- NEI -->
				<div id="NEPCESS" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Psicologia, Ciências da Educação e Serviço Social</h2>
				  	<img style="width:30%;" src="img/nucleos/nepcess.jpg" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O Núcleo de Estudantes de Psicologiade, Ciências da Educação e de Serviço Social da Associação Académica de Coimbra (NEPCESS/AAC) é a entidade que representa os estudantes dos cursos supracitados, com sede na Faculdade de Psicologia e Ciências da Educação da Universidade de Coimbra (FPCE-UC). Tem como competências minorar a distância física entre a Direção-Geral da Associação Académica de Coimbra (DG/AAC) e os estudantes que representa. Paralelamente tem também o objetivo de promover a interligação entre os órgãos de gestão da respetiva Faculdade, salvaguardando sempre os interesses dos estudantes em questões relacionadas com o funcionamento das aulas e/ou serviços da mesma.</p>
					<p>A criação deste núcleo remonta ao ano letivo de 1986/1987, havendo sido inicialmente designado de Núcleo de Estudantes de Psicologia (NEP). Em 1989, o NEP estabeleceu o primeiro protocolo com a Associação Académica de Coimbra, passando a denominar-se NEP/AAC. Designando-se NEP-CE (Núcleo de Estudantes de Psicologia e de Ciências da Educação) com o surgimento da licenciatura em Ciências da Educação em 1991. Em 1996, a DG/AAC reconheceu estatutariamente a existência dos Núcleos, passando estes a fazer parte integrante da mesma. Embora a licenciatura em Serviço Social já existisse anteriormente, só em 2011 passou à nova e atual designação. Em suma, este Núcleo de Estudantes é o mais antigo, desempenhando um papel fundamental na ligação entre a DG/AAC e a FPCE-UC.</p>
					<p>Para saberes mais sobre a história do NEPCESS/AAC podes sempre passar pela FPCE-UC e ver a esposição permanente “Núcleo: Espaço ou Tempo?”.</p>
					desportivas.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nepcessaac.direcao@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Ao entrar na FPCE-UC, a sala à esquerda.</p>
					<br>
					<a href="HTTPS://WWW.FACEBOOK.COM/NEPCESSAAC" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="HTTP://NEPCESSAAC.WEEBLY.COM/" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NERIFE RELAÇOES INTERNACIONAIS DA FACULDADE DE ECONOMIA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NERIFE" class="radius button">
					<img src="img/nucleos/nerife.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NERIFE / AAC </h2>
				</div>
				<!-- NEI -->
				<div id="NERIFE" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Relações Internacionais da Faculdade de Economia</h2>
				  	<img style="width:30%;" src="img/nucleos/nerife.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O NERIFE/AAC, Núcleo de Estudantes de Relações Internacionais da Faculdade de Economia da Associação Académica de Coimbra, fundado em 1997, tem por objetivo representar os estudantes dos três ciclos de estudos em Relações Internacionais da Faculdade de Economia da Universidade de Coimbra e ser também uma plataforma de difusão e aquisição de conhecimentos, organizando e dinamizando atividades extracurriculares relacionadas com as nossas áreas de estudo, de modo a transformar a passagem dos estudantes pela Universidade de Coimbra num momento de aprendizagem constante que enriqueça e diversifique a sua formação pessoal e profissional.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nerife.aac@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Avenida Doutor Dias da Silva, nº 165 – 3004-512 – Coimbra</p>
					<a href="https://www.facebook.com/NERIFEAAC" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NES SOCIOLOGIA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NES" class="radius button">
					<img src="img/nucleos/nes.jpg" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NES / AAC </h2>
				</div>
				<!-- NES -->
				<div id="NES" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Sociologia</h2>
				  	<img style="width:30%;" src="img/nucleos/nes.jpg" onerror="this.src='notfound.png'" alt="nucleo">
					<p>O Núcleo de Estudantes de Sociologia da Associação Académica de Coimbra é parte integrante da Associação Académica de Coimbra (AAC) e representa os estudantes dos cursos de Sociologia da Universidade de Coimbra, sócios efetivos da AAC.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>nes_aac@live.com.pt</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Avenida Doutor Dias da Silva 165, 3004-512 Coimbra</p>
					<br>
					<a href="HTTP://WWW.FACEBOOK.COM/NESOCIOLOGIA" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>
					<a href="HTTP://NESAAC.WIX.COM/SITE" target="_blank;">
					<i class="fa fa-plus fa-2x" style="color:black"></i>
					</a>


				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				<!--  ................................. -->
				<!-- Triggers  NECDEF CIENCIAS DO DESPORTO E DUCAÇÃO FISICA-->
				<div class="col-md-3 col-sm-4 col-xs-6 centrar">
					<a href="#" data-reveal-id="NECDEF" class="radius button">
					<img src="img/nucleos/necdef.png" onerror="this.src='notfound.png'" alt="nucleo">
					</a>
					<h2> NECDEF / AAC </h2>
				</div>
				<!-- NECDEF -->
				<div id="NECDEF" class="reveal-modal" data-reveal>
				  <h2>Núcleo de Estudantes de Ciências do Desporto e Educção Física</h2>
				  	<img style="width:30%;" src="img/nucleos/necdef.png" onerror="this.src='notfound.png'" alt="nucleo">
				  	<p>O NECDEF/AAC sediado no Estádio Universitário de Coimbra representA actualmente cerca de um milhar de estudantes de 1º, 2º e 3 º ciclos. O NECDEF/AAC tem como funções a representação e defesa dos direitos dos seus estudantes princialmente a nivel pedagógico, a oferta de activdades tanto lúdicas, desportivas e culturais como actividades de enriquecimento curricular para preparar o estudante para o mercado de trabalho.</p>
					<br>
					<p><b>Contacto:</b></p>
					<p>necdef@gmail.com</p>
					<br>
					<p><b>Localização:</b></p>
					<p>Faculdade de Ciências do Desporto e Educação Física</p>
					<p>Estádio Universitário de Coimbra</p>
					<p>Pavilhão 3</p>
					<p>3040-156 Coimbra</p>
					<br>
					<a href="https://www.facebook.com/NECDEFAAC" target="_blank;">
					<i class="fa fa-facebook-square fa-2x" style="color:black"></i>
					</a>



				  	<a class="close-reveal-modal">&#215;</a>
				</div>
				
				<!--  ................................. -->
				
				  <br>
				</div>
			</div>
		</div>

	</section>
<!-- .................................................................................... -->
	

   <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();

   $("section").each(function(){
 	if ($(this).offset().top > $(window).height()){	
 			$(this).hide();
 		}
    });
      /* Every time the window is scrolled ... */
   $(window).scroll( function(){
	/* Check the location of each desired element */
    $('section').each( function(i){
        var top_of_object = $(this).offset().top +400;
        var bottom_of_object = $(this).offset().top + $(this).outerHeight();

        var top_of_window = $(window).scrollTop();
        var bottom_of_window = $(window).scrollTop() + $(window).height();
        console.log( top_of_object);
        console.log( bottom_of_window);

        /* If the object is completely visible in the window, fade it in */
        if( bottom_of_window > top_of_object ){
            $(this).slideDown(1800);

        }

    }); 

});
    </script>

 

</body>
<!--............................  FOOTER................................ -->
	<?php
		include 'footer.html';
	?>
<!-- .................................................................................... -->
<!-- .................................................................................... -->	
</html>